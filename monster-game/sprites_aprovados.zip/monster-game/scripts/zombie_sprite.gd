class_name HordeZombieSprite
extends RefCounted

# Sprites approved in the art review. State names match HordeActor/HordeRun.
# This only changes the skeleton (kind == 0), never civilians or other monsters.
const SHEET_ROOT = "res://assets/art/esqueleto_aprovado/"
const TILE = Vector2(384, 288)
const COLS = 6
const BODY_HEIGHT = 181.0
const RUN_COUNT = 36
const JUMP_COUNT = 30
const PUSH_COUNT = 36
const CAPTURE_COUNT = 35

var clips: Dictionary = {}
var legacy_sheets: Dictionary = {}
var legacy_frames: Array = []
var legacy_portrait: AtlasTexture
var stride_run: HordeZombieStride

func _init() -> void:
    stride_run = HordeZombieStride.new()
    var entries = {"run":"corrida.png", "jump":"pulo_pouso.png", "push":"quebrar_veiculos.png", "capture":"captura.png"}
    for state in entries:
        var path = SHEET_ROOT + entries[state]
        if ResourceLoader.exists(path):
            clips[state] = load(path) as Texture2D
    # Keep the old idle/aim rendering available if no matching sprite sheet exists.
    var layout = JSON.parse_string(FileAccess.get_file_as_string("res://assets/art/zombie-fluid-v73.json"))
    if layout is Dictionary:
        for key in layout.sheets:
            legacy_sheets[key] = load("res://assets/art/" + str(layout.sheets[key])) as Texture2D
        for entry in layout.frames:
            var rect = entry.region
            var texture: Texture2D = legacy_sheets[entry.sheet]
            var anchor = Vector2(entry.anchor[0], entry.anchor[1])
            var outline = PackedVector2Array()
            var uvs = PackedVector2Array()
            for point in entry.outline:
                var local = Vector2(point[0], point[1])
                outline.append(local - anchor)
                uvs.append((local + Vector2(rect[0], rect[1])) / texture.get_size())
            legacy_frames.append({"texture":texture, "outline":outline, "uvs":uvs, "height":float(entry.height)})
        legacy_portrait = HordeArt.atlas(legacy_sheets[layout.portrait_sheet], layout.portrait)

func _clip_frame(state:String, phase:float, time:float, landing:float, air_age:float, vy:float) -> int:
    match state:
        "run":
            if landing > 0.0:
                return clampi(int((0.2 - landing) / 0.2 * 6.0) + 24,24,29)
            return posmod(int(fposmod(phase,1.0) * float(RUN_COUNT)),RUN_COUNT)
        "rise":
            return clampi(int(maxf(0.0,air_age) * 30.0),0,11)
        "fly":
            return 12 + posmod(int(time * 9.0),7)
        "fall":
            return 20 + clampi(int(maxf(0.0,vy) / 140.0),0,3)
        "push":
            return clampi(int(clampf(phase,0.0,0.999) * float(PUSH_COUNT)),0,PUSH_COUNT-1)
        "capture":
            return clampi(int(clampf(phase,0.0,0.999) * float(CAPTURE_COUNT)),0,CAPTURE_COUNT-1)
        _:
            return 0

func _new_clip_name(state:String, landing:float) -> String:
    if state in ["run"] and landing <= 0.0: return "run"
    if state in ["run", "rise", "fly", "fall"]: return "jump" if landing > 0.0 or state != "run" else "run"
    if state == "push": return "push"
    if state == "capture": return "capture"
    return ""

func paint(canvas:Node2D, foot:Vector2, height:float, phase:float, state:String, time:float, landing:float, tint:Color, reverse:bool, air_age:float=-1.0, vertical_speed:float=0.0) -> void:
    var clip = _new_clip_name(state, landing)
    if clip != "" and clips.has(clip):
        var frame_id = _clip_frame(state, phase, time, landing, air_age, vertical_speed)
        var col = frame_id % COLS
        var row = int(frame_id / COLS)
        var src = Rect2(col * TILE.x, row * TILE.y, TILE.x, TILE.y)
        var scale = height / BODY_HEIGHT
        var size = TILE * scale
        var position = Vector2(-size.x * 0.5, -size.y + 8.0 * scale)
        canvas.draw_set_transform(foot,0.0,Vector2(-1.0 if reverse else 1.0,1.0))
        canvas.draw_texture_rect_region(clips[clip],Rect2(position,size),src,tint)
        canvas.draw_set_transform_matrix(Transform2D.IDENTITY)
        return
    if state == "run" and landing <= 0.0:
        stride_run.paint(canvas,foot,height,phase,tint,reverse,time)
        return
    if legacy_frames.is_empty(): return
    var idx = 0
    if state in ["idle","aim"]: idx = posmod(int(time * 10.0),24)
    elif state == "push": idx = 64 + posmod(int(time * 14.0),8)
    elif state == "capture": idx = 72 + clampi(int(phase * 8.0),0,7)
    elif state in ["rise","fly"]: idx = 52
    elif state == "fall": idx = 56
    else: idx = 24 + posmod(int(phase * 24.0),24)
    idx = clampi(idx,0,legacy_frames.size()-1)
    var frame = legacy_frames[idx]
    var scale = height / float(frame.height)
    canvas.draw_set_transform(foot,0.0,Vector2(-scale if reverse else scale,scale))
    canvas.draw_polygon(frame.outline,PackedColorArray([tint]),frame.uvs,frame.texture)
    canvas.draw_set_transform_matrix(Transform2D.IDENTITY)
